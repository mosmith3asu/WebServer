# import numpy as np
# import matplotlib.pyplot as plt

class PartnerOBJ:
    def __init__(self):
        pass

class EvaderOBJ:
    def __init__(self):
        pass

